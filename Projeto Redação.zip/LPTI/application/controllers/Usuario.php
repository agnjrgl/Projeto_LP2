<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuario extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->library('session');
    }



    //public id_total = $espec->id_usuario;



    //public function tela_inicial_aluno(){




    public function escrever_texto($id_total){
        $data['id_total'] = $id_total;
        $data['genero'] = $this->db->get('genero')->result();
        $this->load->view('alunos/escolher_genero', $data);
    }





    public function abrir_para_escrever($id, $id_total){
        $this->db->where('id_genero', $id);
        $data['genero'] = $this->db->get('genero')->result();
        $data['id_total'] = $id_total;
        $this->load->view('alunos/pag_onde_escreve', $data);
    }

    public function ler_exemplo($id_total){
        $data['genero'] = $this->db->get('genero')->result();
        $data['id_total'] = $id_total;
        $this->load->view('alunos/escolher_ex', $data);
    }
    public function abrir_para_ler($id, $id_total){
        $this->db->where('id_genero', $id);
        $data['exemplos'] = $this->db->get('exemplos')->result();
        $this->db->where('id_genero', $id);
        $data['genero'] = $this->db->get('genero')->result();
        $data['id_total'] = $id_total;
        $this->load->view('alunos/pag_onde_ler', $data);
    }

    public function abrir_espec($id, $id_total){
        $this->db->where('id_exemplos', $id);
        $data['exemplos'] = $this->db->get('exemplos')->result();
        $data['genero'] = $this->db->get('genero')->result();
        $data['id_total'] = $id_total;
        $this->load->view('alunos/pag_ler_ex_spec', $data);
    }
    public function mostrar_texto($id, $id_total){
        $this->db->where('id_texto', $id);
        $data['texto'] = $this->db->get('texto')->result();
        $data['genero'] = $this->db->get('genero')->result();
        $data['id_total'] = $id_total;
        $this->load->view('alunos/pag_ler_rascunho_spec', $data);
    }

    public function excluir_texto($id_txt, $id_total){
        $txts = $this->db->get('texto')->result();
        $var;
        foreach($txts as $txt){
            if($txt->id_texto == $id_txt){
                $var = $txt->id_usuario;
            }
        }
        $this->db->where('id_texto', $id_txt);
        if($this->db->delete('texto')){
            /*$this->db->where('id_usuario', $var);
            $data['rascunhos'] = $this->db->get('texto')->result();
            $data['genero'] = $this->db->get('genero')->result();
            $this->load->view('alunos/rascunhos', $data);*/
            $this->rascunhos($id_total);
        }
    }
    public function abrir_alterar_rascunho($id, $id_total){
        $data['id_total'] = $id_total;
        $this->db->where('id_texto', $id);
         $data['texto'] = $this->db->get('texto')->result();
        $data['genero'] = $this->db->get('genero')->result();


        $this->load->view('alunos/pag_alterar_rascunho_spec', $data);
    }



    public function alterar_rascunho($id, $id_total, $id_genero){
        //$data['id_genero'] = $this->input->post('id_genero');

        //$data['id_usuario'] = $id_total;
        $data['conteudo'] = $this->input->post('descricao');
        $data['titulo'] = $this->input->post('titulo');
        //$data['permissao'] = $this->input->post('permissao');
        $this->db->where('id_texto', $id);
        if($this->db->update('texto', $data)){

            redirect(base_url('../usuario/rascunhos/'.$id_total));
        }

    }
        public function abrir_sobre($id_total){
        $data['id_total'] = $id_total;
        $this->load->view('alunos/sobre', $data);
    }


    public function adicionar_rascunho($genero, $id_total){
        $data['estado_de_correcao'] = 'RASCUNHO';
        $data['rascunho_ou_nao'] = true;
        $data['id_genero'] = $genero;

        $data['id_usuario'] = $id_total;
        $data['conteudo'] = $this->input->post('descricao');
        $data['titulo'] = $this->input->post('titulo');
        $data['permissao'] = false;

        if($this->db->insert('texto', $data)){
            redirect(base_url('../usuario/exibe_filtro_rascunhos/'.$id_total));
        }

    }







    public function tornar_rascunho_corrigivel($id_txt, $id_total){
        $data['estado_de_correcao'] = 'EM_CORRECAO';
        $data['rascunho_ou_nao'] = false;
        $data['envio'] = date('Y-m-d H:i:s');

        $txts = $this->db->get('texto')->result();
        $var;
        foreach($txts as $txt){
            if($txt->id_texto == $id_txt){
                $var = $txt->id_usuario;
            }
        }

        $this->db->where('id_texto', $id_txt);


        if($this->db->update('texto', $data)){
            $this->rascunhos($id_total);
        }
    }
    public function rascunhos($id_user){
        $this->db->where('id_usuario', $id_user);
        $data['rascunhos'] = $this->db->get('texto')->result();
        $data['genero'] = $this->db->get('genero')->result();
        $data['id_total'] = $id_user;
        $this->load->view('alunos/rascunhos', $data);
    }

    public function acessar_perfil($id_user){
        $this->db->where('id_usuario', $id_user);
        $data['usuario'] = $this->db->get('usuario')->result();
        $data['id_total'] = $id_user;
        $this->load->view('alunos/acessar_perfil', $data);
    }

    public function home_abrir_aluno($id){
        //print_r($id);
       $data['espec']['id_usuario'] = $id;
        $data['id_total'] = $id;
        $this->load->view('alunos/tela_inicial_aluno', $data);

    }





    public function exibe_filtro_rascunhos($id_user){
        $this->db->where('id_usuario', $id_user);
        $data['rascunhos'] = $this->db->get('texto')->result();
        $data['genero'] = $this->db->get('genero')->result();
        $data['id_total'] = $id_user;
        $this->load->view('alunos/rascunhos_rascunhos', $data);
    }
public function exibe_filtro_corrigidos($id_user){
        $this->db->where('id_usuario', $id_user);
        $data['rascunhos'] = $this->db->get('texto')->result();
        $data['genero'] = $this->db->get('genero')->result();
        $data['id_total'] = $id_user;
        $this->load->view('alunos/rascunhos_corrigidos', $data);
    }
public function exibe_filtro_em_correcao($id_user){
        $this->db->where('id_usuario', $id_user);
        $data['rascunhos'] = $this->db->get('texto')->result();
        $data['genero'] = $this->db->get('genero')->result();
        $data['id_total'] = $id_user;
        $this->load->view('alunos/rascunhos_em_correcao', $data);
    }




    public function abrir_alterar_conta($id){
        $this->db->where('id_usuario', $id);
        $data['usuario'] = $this->db->get('usuario')->result();
        $data['id_total'] = $id;
        $data['msg_escondida_abrir'] = false;
        $this->load->view('alunos/alterar_senha', $data);

    }

    public function alterar_cadastro($id){
        $data['id_total'] = $id;
        $login = $this->input->post('login');
        $senha_antiga = sha1($this->input->post('senha_antiga'));



        $senha_nova1 = sha1($this->input->post('nova_senha1'));
        $senha_nova2 = sha1($this->input->post('nova_senha2'));


        $logins = $this->db->get('usuario')->result();
        $pode_alterar = true;


        foreach($logins as $log){
            if($log->login == $login and $log->id_usuario != $id)
                $pode_alterar=false;

        }

        $this->db->where('id_usuario', $id);
        $data['usuario'] = $this->db->get('usuario')->result();

        if($data['usuario'][0]->senha != $senha_antiga) $pode_alterar=false;

        if($senha_nova1 != $senha_nova2) $pode_alterar=false;

        if($pode_alterar==true){
            $altera['login'] = $login;

            if($senha_nova1 != 'da39a3ee5e6b4b0d3255bfef95601890afd80709')
            $altera['senha'] = $senha_nova1;

            $altera['nome']=$this->input->post('nome');
            $this->db->where('id_usuario', $id);
            if($this->db->update('usuario', $altera)){
                redirect(base_url('../usuario/acessar_perfil/'.$id));
            }

        }else{

            $this->db->where('id_usuario', $id);
            $data['usuario'] = $this->db->get('usuario')->result();
            $data['id_total'] = $id;
            $data['msg_escondida_abrir'] = true;

            $this->load->view('alunos/alterar_senha', $data);

        }

    }
    public function visualizar_correcao ($id_texto, $id_usuario){
            $data['id_total'] = $id_usuario;
            $this->db->where('id_texto', $id_texto);
            $data['texto'] = $this->db->get('texto')->result();
            //print_r($data['texto']);
            $this->load->view('alunos/visualizar_correcao', $data);
    }



}

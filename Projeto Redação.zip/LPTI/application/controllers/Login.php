<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->library('session');
    }

    public function index()
    {
        $data['msg'] = '';
        $data['url'] = base_url();
        $data['modal'] = '';
        $this->parser->parse('login', $data);
    }

    public function efetuar_login(){
        $login['login'] = $this->input->post('txt_nome');
        $login['senha'] = sha1($this->input->post('txt_senha'));
        $data = $this->db->get_where('usuario', $login)->result_array();
        if(count($data) > 0){
            $array=array("login"=>true, "tipo"=>$data[0]['tipo'], "bool"=>true);//usuario especifico
            $this->session->set_userdata($array);
            $user['url']=base_url();
            $user['espec'] = $data[0];

            if($data[0]['tipo'] == 0){ //aluno
                //echo $user['espec'];
                redirect(base_url('../usuario/home_abrir_aluno/'.$user['espec']['id_usuario']));}
                //$this->parser->parse('alunos/tela_inicial_aluno', $user);}
            else if($data[0]['tipo'] == 1){
                redirect(base_url('../usuario/home_abrir_estagiario/'.$user['espec']['id_usuario']));}

                //$this->parser->parse('estagiario/tela_inicial_estag', $user);}
            else if($data[0]['tipo'] == 2){
                redirect(base_url('../professor/home_abrir_professor/'.$user['espec']['id_usuario']));}
                //$this->parser->parse('professor/tela_inicial_professor', $user);}


        }
        else{
            $this->session->sess_destroy();
            $data['msg'] = 'Login ou Senha Inválidos';
            $data['url'] = base_url();
            $data['modal'] = "$(window).on('load',function(){
                          $('#login-modal').modal('show');
                          });";
            $this->parser->parse('login', $data);
        }
    }

    public function efetuar_logout(){
        $this->load->library('session');
        $this->session->sess_destroy();
        redirect('/');
    }

    public function loginAsAdm(){
        $this->load->library('session');
        $data['url'] = base_url();
        $data['modal'] = "";
        $this->parser->parse('telaAdm', $data);
    }

    public function loginAsCoord($tipo){
        $this->load->library('session');
        $data['url'] = base_url();
        $data['Tipo'] = $tipo;
        $data['modal'] = "";
        $this->parser->parse('telaCoord', $data);
    }

    public function loginAsEst(){
        $this->load->library('session');
        $data['url'] = base_url();
        $data['modal'] = "";
        $this->parser->parse('telaEst', $data);
    }

    public function telaInicial(){
        $this->load->library('session');
        $data['url'] = base_url();
        $this->load->view('alunos/tela_inicial_aluno', $data);
    }
}

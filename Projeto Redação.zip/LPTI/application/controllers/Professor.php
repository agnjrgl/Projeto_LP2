<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Professor extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->library('session');
    }



    //public id_total = $espec->id_usuario;



    //public function tela_inicial_aluno(){




    /*public function escrever_texto($id_total){

        $data['id_total'] = $id_total;
        $data['genero'] = $this->db->get('genero')->result();
        $this->load->view('alunos/escolher_genero', $data);

    }





    public function abrir_para_escrever($id, $id_total){
        $this->db->where('id_genero', $id);
        $data['genero'] = $this->db->get('genero')->result();
$data['id_total'] = $id_total;
        $this->load->view('alunos/pag_onde_escreve', $data);
    }

    public function ler_exemplo($id_total){
        $data['genero'] = $this->db->get('genero')->result();
        $data['id_total'] = $id_total;
        $this->load->view('alunos/escolher_ex', $data);
    }
    public function abrir_para_ler($id, $id_total){
        $this->db->where('id_genero', $id);
        $data['exemplos'] = $this->db->get('exemplos')->result();
        $this->db->where('id_genero', $id);
        $data['genero'] = $this->db->get('genero')->result();
        $data['id_total'] = $id_total;
        $this->load->view('alunos/pag_onde_ler', $data);
    }

    public function abrir_espec($id, $id_total){
        $this->db->where('id_exemplos', $id);
        $data['exemplos'] = $this->db->get('exemplos')->result();
        $data['genero'] = $this->db->get('genero')->result();
        $data['id_total'] = $id_total;
        $this->load->view('alunos/pag_ler_ex_spec', $data);
    }*/
    public function enviar_exemplos($id){
        $data['espec']['id_usuario'] = $id;
        $data['id_total'] = $id;
        $data['genero'] = $this->db->get('genero')->result();
        $this->load->view('professor/enviar_exemplos', $data);
    }
    public function escrever_exemplos($id, $id_total){
        $this->db->where('id_genero', $id);
        $data['espec']['id_usuario'] = $id;
        $data['id_total'] = $id;
        $data['genero'] = $this->db->get('genero')->result();
        $this->load->view('professor/escrever_exemplos', $data);
    }
    public function adicionar_exemplos($genero, $id_total){

        $data['id_genero'] = $genero;
        $data['conteudo'] = $this->input->post('descricao');
        $data['titulo'] = $this->input->post('titulo');

        if($this->db->insert('exemplos', $data)){
            redirect(base_url('../professor/home_abrir_professor/'.$id_total));
        }

    }
    public function criar_novo_genero($id_total){
        $data['id_total'] = $id_total;
        $this->load->view('professor/pagina_onde_cria_genero', $data);
    }

    public function mostrar_texto($id, $id_total){
        $this->db->where('id_texto', $id);
        $data['texto'] = $this->db->get('texto')->result();
        $data['genero'] = $this->db->get('genero')->result();
        $data['id_total'] = $id_total;
        $this->load->view('professor/pag_ler_texto_spec', $data);
    }/*

    public function excluir_texto($id_txt, $id_total){
        $txts = $this->db->get('texto')->result();
        $var;
        foreach($txts as $txt){
            if($txt->id_texto == $id_txt){
                $var = $txt->id_usuario;
            }
        }
        $this->db->where('id_texto', $id_txt);
        if($this->db->delete('texto')){

            $this->rascunhos($id_total);
        }
    }
    public function abrir_alterar_rascunho($id, $id_total){
        $data['id_total'] = $id_total;
        $this->db->where('id_texto', $id);
         $data['texto'] = $this->db->get('texto')->result();
        $data['genero'] = $this->db->get('genero')->result();


        $this->load->view('alunos/pag_alterar_rascunho_spec', $data);
    }



    public function alterar_rascunho($id, $id_total, $id_genero){
        //$data['id_genero'] = $this->input->post('id_genero');

        //$data['id_usuario'] = $id_total;
        $data['conteudo'] = $this->input->post('descricao');
        $data['titulo'] = $this->input->post('titulo');
        //$data['permissao'] = $this->input->post('permissao');
        $this->db->where('id_texto', $id);
        if($this->db->update('texto', $data)){

            redirect(base_url('../usuario/rascunhos/'.$id_total));
        }

    }



    public function adicionar_rascunho($genero, $id_total){
        $data['estado_de_correcao'] = 'RASCUNHO';
        $data['rascunho_ou_nao'] = true;
        $data['id_genero'] = $genero;

        $data['id_usuario'] = $id_total;
        $data['conteudo'] = $this->input->post('descricao');
        $data['titulo'] = $this->input->post('titulo');
        $data['permissao'] = false;

        if($this->db->insert('texto', $data)){
            redirect(base_url('../usuario/rascunhos/'.$id_total));
        }

    }







    public function tornar_rascunho_corrigivel($id_txt, $id_total){
        $data['estado_de_correcao'] = 'EM_CORRECAO';
        $data['rascunho_ou_nao'] = false;




        $txts = $this->db->get('texto')->result();
        $var;
        foreach($txts as $txt){
            if($txt->id_texto == $id_txt){
                $var = $txt->id_usuario;
            }
        }

        $this->db->where('id_texto', $id_txt);


        if($this->db->update('texto', $data)){
            $this->rascunhos($id_total);
        }
    }
    public function rascunhos($id_user){
        $this->db->where('id_usuario', $id_user);
        $data['rascunhos'] = $this->db->get('texto')->result();
        $data['genero'] = $this->db->get('genero')->result();
        $data['id_total'] = $id_user;
        $this->load->view('alunos/rascunhos', $data);
    }
*/
    public function acessar_perfil($id_user){
        $this->db->where('id_usuario', $id_user);
        $data['usuario'] = $this->db->get('usuario')->result();
        $data['id_total'] = $id_user;
        $this->load->view('professor/acessar_perfil', $data);
    }

    public function home_abrir_professor($id){
        //print_r($id);
       $data['espec']['id_usuario'] = $id;
        $data['id_total'] = $id;
        $this->load->view('professor/tela_inicial_professor', $data);

    }

    public function banco_correcao($id){
        $data['id_total'] = $id;
        //$data['texto'] =  //$this->db->get('texto')->result();
        $this->db->select('*');
        $this->db->from('texto');
        $this->db->order_by('data_criacao', 'asc');
        $data['texto'] = $this->db->get()->result();

        $data['usuario'] = $this->db->get('usuario')->result();
        $data['genero'] = $this->db->get('genero')->result();
        $this->load->view('professor/banco_de_textos', $data);
    }

    public function abrir_para_corrigir($id_txt, $id_total){
        $data['id_total'] = $id_total;
        $data['genero'] = $this->db->get('genero')->result();
        $data['usuario'] = $this->db->get('usuario')->result();
        $this->db->where('id_texto', $id_txt);
        $data['texto'] = $this->db->get('texto')->result();
        $this->load->view('professor/pag_onde_corrigi', $data);
    }

    public function corrigi_txt($id_txt, $id_total){
        $data['id_total'] = $id_total;
        $altera['nota_obs'] = $this->input->post('nota_obs');
        $altera['estado_de_correcao'] = 'CORRIGIDO';
        $altera['rascunho_ou_nao'] = '0';
        $altera['id_corretor'] = $id_total;
        $this->db->where('id_texto', $id_txt);
        if($this->db->update('texto', $altera)){
            $this->banco_correcao($id_total);
        }
    }




/*



    public function exibe_filtro_rascunhos($id_user){
        $this->db->where('id_usuario', $id_user);
        $data['rascunhos'] = $this->db->get('texto')->result();
        $data['genero'] = $this->db->get('genero')->result();
        $data['id_total'] = $id_user;
        $this->load->view('alunos/rascunhos_rascunhos', $data);
    }
public function exibe_filtro_corrigidos($id_user){
        $this->db->where('id_usuario', $id_user);
        $data['rascunhos'] = $this->db->get('texto')->result();
        $data['genero'] = $this->db->get('genero')->result();
        $data['id_total'] = $id_user;
        $this->load->view('alunos/rascunhos_corrigidos', $data);
    }
public function exibe_filtro_em_correcao($id_user){
        $this->db->where('id_usuario', $id_user);
        $data['rascunhos'] = $this->db->get('texto')->result();
        $data['genero'] = $this->db->get('genero')->result();
        $data['id_total'] = $id_user;
        $this->load->view('alunos/rascunhos_em_correcao', $data);
    }


*/

    public function abrir_alterar_conta($id){
        $this->db->where('id_usuario', $id);
        $data['usuario'] = $this->db->get('usuario')->result();
        $data['id_total'] = $id;
        $data['msg_escondida_abrir'] = false;
        $this->load->view('professor/alterar_senha', $data);

    }

    public function alterar_cadastro($id){
        $data['id_total'] = $id;
        $login = $this->input->post('login');
        $senha_antiga = sha1($this->input->post('senha_antiga'));
        $senha_nova1 = sha1($this->input->post('nova_senha1'));
        $senha_nova2 = sha1($this->input->post('nova_senha2'));

        $logins = $this->db->get('usuario')->result();
        $pode_alterar = true;


        foreach($logins as $log){
            if($log->login == $login and $log->id_usuario != $id)
                $pode_alterar=false;

        }

        $this->db->where('id_usuario', $id);
        $data['usuario'] = $this->db->get('usuario')->result();

        if($data['usuario'][0]->senha != $senha_antiga) $pode_alterar=false;

        if($senha_nova1 != $senha_nova2) $pode_alterar=false;

        if($pode_alterar==true){
            $altera['login'] = $login;
            $altera['senha'] = $senha_nova1;
            $this->db->where('id_usuario', $id);
            if($this->db->update('usuario', $altera)){
                $this->load->view('professor/acessar_perfil', $data);
            }

        }else{

            $this->db->where('id_usuario', $id);
            $data['usuario'] = $this->db->get('usuario')->result();
            $data['id_total'] = $id;
            $data['msg_escondida_abrir'] = true;
            $this->load->view('alunos/alterar_senha', $data);

        }



    }

    public function pag_gerenciar_contas($id){
        $data['id_total'] = $id;
        $this->load->view('professor/escolha_de_gerencia', $data);
    }


    public function pag_adicionar_alunos($id){
        $data['id_total']=$id;
        $this->load->view('/professor/pag_onde_adiciona_aluno', $data);
    }

    public function pag_adicionar_estagiarios($id){
        $data['id_total']=$id;
        $this->load->view('', $data);
    }

    public function pag_excluir_alunos($id_total){
        $data['id_total']=$id_total;
        $this->db->from('usuario');
        $this->db->where('tipo', 0);
        $data['alunos'] = $this->db->get()->result();
        /*$this->db->select('login');
        $this->db->from('usuario');
        $this->db->order_by('data_cadastro', 'asc');
        $data['texto'] = $this->db->get()->result();
        //DADOS DOS ALUNOS POR ORDEM ALFABETICA
        //SELECT login FROM `usuario` WHERE flag <> 0 and tipo = 0  */
        $this->load->view('/professor/pag_onde_exclui_aluno', $data);

    }

    public function exclusao_usuario($id_usuario, $id_total){
         $data['id_total']=$id_total;
         $this->db->from('usuario');
        $this->db->where('tipo', 0);
        $data['alunos'] = $this->db->get()->result();
         $altera['flag'] = 0;
         $this->db->from('usuario');
         $this->db->where('id_usuario', $id_usuario);
         if($this->db->update('usuario', $altera)){
                redirect('..professor/pag_excluir_alunos/'.$id_total);
            }

    }

    public function pag_excluir_estagiarios($id){
        $data['id_total']=$id;
        $this->load->view('', $data);
    }

    public function pag_reativar_alunos($id_total){
        $data['id_total']=$id_total;
        $this->db->from('usuario');
        $this->db->where('tipo', 0);
        $data['alunos'] = $this->db->get()->result();
        $this->load->view('/professor/pag_onde_reativa_aluno', $data);
    }
    public function reativacao_usuario($id_usuario, $id_total){
         $data['id_total']=$id_total;
         $this->db->from('usuario');
        $this->db->where('tipo', 0);
        $data['alunos'] = $this->db->get()->result();
         $altera['flag'] = 1;
         $this->db->from('usuario');
         $this->db->where('id_usuario', $id_usuario);
         if($this->db->update('usuario', $altera)){
                redirect('..professor/pag_reativar_alunos/'.$id_total);
            }

    }


    public function pag_reativar_estagiarios($id){
        $data['id_total']=$id;
        $this->load->view('', $data);
    }


    //esse adiciona
    public function adicionar_aluno($id){
        $data['id_total']=$id;

            $adic['email'] = $this->input->post('email');
            $user='';
            $i=0;
            while((string)$adic['email'][$i]!='@'){
                $user=$user.$adic['email'][$i];
                $i++;
            }
            $adic['login'] = $user.rand(100, 999);


            date_default_timezone_set('America/Sao_Paulo');
            $senha = date('HisdmY');

            //string substr ( string $string , int $start [, int $length ] )
            for($i=0; $i<=13; $i++){
            $senha1[$i] = substr ($senha, $i, $i);
        }
            for($i=0; $i<=12; $i++){
            $senha += $senha1[$i]*$senha1[$i++];
        }
            $senha = strtoupper(dechex ($senha));
            $adic['senha'] = sha1($senha);
            $adic['flag'] = 0;
            $adic['tipo'] = 0;
            if($this->db->insert('usuario', $adic)){
            redirect(base_url('../professor/pag_gerenciar_contas/'.$id));
        }
    }


}

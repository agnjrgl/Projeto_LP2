<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Business Casual - Start Bootstrap Theme</title>

    <?php
        echo link_tag("assets/vendor/bootstrap/css/bootstrap.min.css");
        echo link_tag("https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800");
        echo link_tag("https://fonts.googleapis.com/css?family=Josefin+Slab:100,300,400,600,700,100italic,300italic,400italic,600italic,700italic");
        echo link_tag("assets/css/business-casual.css");
    ?>

  </head>
<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
    width: 80%;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
</style>

  <body>

    <div class="tagline-upper text-center text-heading text-shadow text-white mt-5 d-none d-lg-block">Sistema de Correções do CEFET-MG</div>
    <div class="tagline-lower text-center text-expanded text-shadow text-uppercase text-white mb-5 d-none d-lg-block">Envie sua redação para o nosso banco de redaçoes para ser corrigida.</div>

         <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-faded py-lg-4">
      <div class="container">
        <a class="navbar-brand text-uppercase text-expanded font-weight-bold d-lg-none" href="#">Start Bootstrap</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav mx-auto">
            <li class="nav-item active px-lg-4">

              <?php echo anchor(base_url('../usuario/home_abrir_aluno/'.$id_total), "Home", array('class'=>'nav-link text-uppercase text-expanded'));?>
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item px-lg-4">




<?php echo anchor(base_url('../usuario/escrever_texto/'.$id_total), "Escrever", array('class'=>'nav-link text-uppercase text-expanded'));?>


            </li>
            <li class="nav-item px-lg-4">
                <?php echo anchor(base_url('../usuario/acessar_perfil/'.$id_total), "Perfil", array('class'=>'nav-link text-uppercase text-expanded'));?>

            </li>
                        <li class="nav-item px-lg-4">
                <?php echo anchor(base_url('../usuario/abrir_sobre/'.$id_total), "Sobre", array('class'=>'nav-link text-uppercase text-expanded'));?>


            </li>
            <li class="nav-item px-lg-4">
                <?php echo anchor(base_url('../login/efetuar_logout'), "Logout", array('class'=>'nav-link text-uppercase text-expanded'));?>


            </li>
                        </li>

          </ul>
        </div>
      </div>
    </nav>

<!-- FIM-->
    <div class="container">

      <div class="bg-faded p-4 my-4">
        <!-- Image Carousel -->
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          </ol>
          <div class="carousel-inner" role="listbox">
            <div class="carousel-item active">


              <div class="carousel-caption d-none d-md-block">
                <h3 class="text-shadow">First Slide</h3>
                <p class="text-shadow">This is the caption for the first slide.</p>
              </div>
            </div>
            <div class="carousel-item">

              <div class="carousel-caption d-none d-md-block">
                <h3 class="text-shadow">Second Slide</h3>
                <p class="text-shadow">This is the caption for the second slide.</p>
              </div>
            </div>
            <div class="carousel-item">

              <div class="carousel-caption d-none d-md-block">
                <h3 class="text-shadow">Third Slide</h3>
                <p class="text-shadow">This is the caption for the third slide.</p>
              </div>
            </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
        <!-- Welcome Message -->


      <div class="bg-faded p-4 my-4">
        <hr class="divider">
        <h2 class="text-center text-lg text-uppercase my-0"><strong>Ler exemplos de <?php echo $genero[0]->nome; ?></strong>
        </h2>
        <hr class="divider">
            <hr>
          <p style="color: black;"></p>
<br><h4 id="homeHeading">Escolha um exemplo de <?php  echo $genero[0]->nome;?> para ler</h4>
          <br>
<table >
            <tr>
            <th>Textos</th>
            </tr>
          <?php
            foreach($exemplos as $ex){
                echo "<tr> <td> <b>".$ex->titulo."</b>".br().
                substr($ex->conteudo, 0, 78).br().substr($ex->conteudo, 79, 76)."...".
                br().anchor(base_url('../usuario/abrir_espec/'.$ex->id_exemplos.'/'.$id_total), 'Mostrar mais...', array('class'=>'btn btn-outline-success btn-sm'))."</td></tr>";
            }
        ?>
        <tr>
        <td>
                <hr>
                <?php
                    echo anchor(base_url('../usuario/ler_exemplo/'.$id_total)
                    , "Voltar", array('class'=>'btn btn-outline-info btn-sm')).
                    " | ".
                    anchor(base_url('../usuario/escrever_texto/'.$id_total), "Escreva um texto agora!"
                    , array('class'=>'btn btn-outline-info btn-sm'));
                ?>
        </td>
        </tr>
        </table>

        <hr>

            </div>


    <!-- /.container -->

    <footer class="bg-faded text-center py-5">
      <div class="container">
        <p class="m-0">Copyright &copy; Your Website 2017</p>
      </div>
    </footer>



    <!-- Bootstrap core JavaScript -->
    <?php
        echo link_tag("assets/vendor/jquery/jquery.min.js");
        echo link_tag("assets/vendor/bootstrap/js/bootstrap.bundle.min.js");
    ?>


  </body>

</html>

# LPTI
Projeto LPTI - Conselho de Classe - Birma, João Marcos, Laís, Matheus Amâncio
